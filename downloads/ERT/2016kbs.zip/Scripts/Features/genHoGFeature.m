function x = genHoGFeature(I)
             I_gray = I;
    if size(I, 3) > 1
        I_gray = rgb2gray(uint8(I));
        % %I_yuv = rgb2hsv(I);
       % x = I(:);
       % return;
    end
            temp_hog = fhog(single(I_gray)/ 255, 4,9);
            x = temp_hog(:,:,1:31);
            %x_hist = hist(I(:),32);  
            %x_hist = x_hist ./ 100;
            %x = [x(:);x_hist(:)];
            %x = double(I);
end