function [ X,I ] = getScaleSample( im,bb,scale,sz )
%GETCONTEXT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    
     I_gray = im;
    if size(im, 3) > 1
        I_gray = rgb2gray(uint8(im));
        % %I_yuv = rgb2hsv(I);
       % x = I(:);
       % return;
    end

     p_bb = bb';

     p_bb = [p_bb([1 2]),p_bb([3 4])*scale];

     p = bb2est(p_bb',sz);

     I = warpimg_s(double(im),affparam2mat(p'), sz);
     %figure(13);
     %imshow(I,[]);
     X = genHoGFeature(I);
     X = X(:);

end


function wimg = warpimg_s(img, p, sz)

    if size(img, 3) == 1
        wimg = warpgray(img,p,sz);
    else
        channel = size(img, 3);
        wimg = zeros(sz(1),sz(2),channel,size(p,2));

        for i = 1:channel
           I = img(:,:,i);

             wimg(:,:,i,:) = warpgray(I,p,sz);
        end


    end
end


function wimg = warpgray(img,p,sz)

    if (size(p,1) == 1)
        p = p(:);
    end
    w = sz(2);  h = sz(1);  n = size(p,2);
    %[x,y] = meshgrid(1:w, 1:h);
    [x,y] = meshgrid([1:w]-w/2, [1:h]-h/2);
    pos = reshape(cat(2, ones(h*w,1),x(:),y(:)) * [p(1,:) p(2,:); p(3:4,:) p(5:6,:)], [h,w,n,2]);
    wimg = squeeze(interp2(img, pos(:,:,:,1), pos(:,:,:,2)));
    wimg(isnan(wimg)) = 0;
end