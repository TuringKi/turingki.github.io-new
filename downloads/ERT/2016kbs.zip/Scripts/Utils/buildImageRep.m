%%
%建立图像的表示形式：
%构�?积分图和积分直方图�?
%
function [image_rep] = buildImageRep(image)
	image_rep.img = image;
	image_rep.iH = integral(image);%积分�?
	image_rep.img_rect = [1, 1,size(image)]';