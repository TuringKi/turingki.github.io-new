%% showResults: function description
function [out_figs] = showResults(figs,im_o,bb,max_score)
global opt;
global model;
	rect_position = bb;
    rect_position([1 2]) = bb([1 2]) - bb([3 4])/2;
    out_figs = figs;
	if isempty(out_figs)
        
        if  opt.DEBUG == 1
            
            w0 = opt.tmplsize(1);
            h0 = opt.tmplsize(2);
            im_extend = zeros(w0* 10, h0* 10,size(im_o, 3));
           
            count = 1;
            
            
            svs = [model.pos model.nag];
            imgs = [svs.imgs, svs.imgs];
            
            %[~, idxs] = sort(svs.W,'descend');
            
            for i = 1:10
                for j = 1:10
                    %imshow(uint8(model.svs(count).img), [])
                     im_extend((i - 1)*w0 + 1 : i*w0,(j - 1)*h0 + 1 : j*h0,:) = imgs{count};
                     count = count + 1;
                     if count > length(imgs)
                        break;
                     end
                end
                if count > length(imgs)
                    break;
                end
            end
            out_figs.fig_app_handle = figure('Name',['Appearances']);
             set(gcf,'DoubleBuffer','on','MenuBar','none');
            out_figs.app_handle = imshow(uint8(im_extend), 'Border','tight', 'initialmagnification','fit');
            
            
        end
        
        
		out_figs.fig_handle = figure('Name',['Tracker - ERT']);
		out_figs.im_handle = imshow(im_o, 'Border','tight', 'InitialMag',200);
		out_figs.rect_handle = rectangle('Position',rect_position, 'EdgeColor','g', 'LineWidth',5);
        out_figs.score_handle = text(rect_position(1) + 4,rect_position(2) + 4,num2str(max_score),'Color','g','FontWeight','bold', 'FontSize',18);
    else
        
        
        if opt.DEBUG == 1
            
            w0 = opt.tmplsize(1);
            h0 = opt.tmplsize(2);
            im_extend = zeros(w0* 10, h0* 10,size(im_o, 3));
           
            count = 1;
            svs = [model.pos model.nag];
            imgs = [svs.imgs, svs.imgs];
            
            %[~, idxs] = sort([svs.w],'descend');
            
            for i = 1:10
                for j = 1:10
                    %imshow(uint8(model.svs(count).img), [])
                   
                     im_extend((i - 1)*w0 + 1 : i*w0,(j - 1)*h0 + 1 : j*h0,:) = imgs{count};
                     count = count + 1;
                     if count > length(imgs)
                        break;
                     end
                end
                if count > length(imgs)
                    break;
                end
            end
            set(out_figs.app_handle, 'CData', uint8(im_extend));
        end
        
		set(out_figs.im_handle, 'CData', im_o);
		set(out_figs.rect_handle, 'Position', rect_position);
        set(out_figs.score_handle,'Position', rect_position([1 2]) + 20 ,   'String',num2str(max_score));
	end
	drawnow
end
