function [est,max_score] = track(opt,im,model,DEBUG)

   	 [S ests] = ParticleFilterSampler(im,opt.est,opt.tmplsize,opt.particles.N,opt.particles.sigma);
     
     %now we get all the hog features
     Z = [];
     for i = 1:size(S,3)
         I = S(:,:,i);
         temp = genHoGFeature(I);
          Z(:,i) = temp(:);
     end
     scores = zeros(1,size(S,3));
     
     nag = model.nag;
     pos = model.pos;
     
     N_nag = length(nag.W);
     N_pos = length(pos.W);
   
     for i = 1:size(Z,2)
         if N_nag > 0
             for j = 1:N_nag
                scores(1,i) = scores(1,i) - nag.W(j)*(Z(:,i)'*nag.X(:,j) / (norm(Z(:,i)) * norm(nag.X(:,j))));
             end
         end
         for j = 1:N_pos
            scores(1,i) = scores(1,i) + pos.W(j)*(Z(:,i)'*pos.X(:,j) / (norm(Z(:,i)) * norm(pos.X(:,j))));
         end
         %scores(1,i) = scores(1,i) * Overlap(bb',samples(:,i));
     end
    
    i_max = find(scores == max(scores),1);
    max_score = scores(1,i_max);
    est = affparam2mat(ests(:,i_max));   
    N = opt.N_search_scale;
    %sigma = [0 0 0.03 0 0.0 0.0];
    particles = repmat(affparam2geom(est(:)), [1,N]);
    scales = 1 - opt.scale_search_range / 2:opt.scale_search_range / N:1 + opt.scale_search_range / 2;
    scales = scales(find(scales ~= 1));
    for i = 1:N
        particles(3,i) = particles(3,i) * scales(i);
    end
    S = warpimg(double(im), affparam2mat(particles), opt.tmplsize);
    Z = [];
    scores = zeros(1,size(S,3));
    for i = 1:size(S,3)
         I = S(:,:,i);
         temp = genHoGFeature(I);
          Z(:,i) = temp(:);
    end
    
     
    for i = 1:size(Z,2)
         if N_nag > 0
             for j = 1:N_nag
                scores(1,i) = scores(1,i) - nag.W(j)*(Z(:,i)'*nag.X(:,j) / (norm(Z(:,i)) * norm(nag.X(:,j))));
             end
         end
         for j = 1:N_pos
            scores(1,i) = scores(1,i) + pos.W(j)*(Z(:,i)'*pos.X(:,j) / (norm(Z(:,i)) * norm(pos.X(:,j))));
         end
    end
    
    i_max = find(scores == max(scores),1);
    max_score = scores(1,i_max);
    est = affparam2mat(particles(:,i_max));    
    
end