%% track: function description
function [model] = updateModel(opt,model,im,DEBUG)
	bb =est2bb(opt.tmplsize,opt.est);
    if isempty(model)
        
        model.nag = [];
        model.nag.X = [];
        model.nag.W = [];
        if DEBUG
            model.nag.imgs = {};
        end
        model.pos = [];
        model.pos.X = [];
        model.pos.W = [];
        if DEBUG
            model.pos.imgs = {};
        end
        model.first = [];
        model.first.built = false;
    end
   nag = model.nag;
   pos = model.pos;
   first = model.first;
    %positive and nagtive samples from pre-frames:
    if isempty(pos)
        N_pos = 0;
    else
        N_pos = length(pos.W);
    end
   
    if isempty(nag)
        N_nag = 0;
    else
        N_nag = length(nag.W);
    end
    
    N_scale = opt.N_scale;
   

	[samples,XX] = RadialSampler(im,bb',opt.tmplsize,2*opt.radius,5,16);
	N = size(samples,2);
    %handling new nagtive samples first:
    count = 1;
    while count <= size(samples,2) - 1
           
            I = XX{count};
            temp = genHoGFeature(I);
            X(:,count) = temp(:);
            if DEBUG
                imgs{count} = I;
            end
            count = count + 1;
    end
    %handling scale samples
    scales = 1 - opt.scale_range / 2:opt.scale_range / N_scale:1 + opt.scale_range / 2;
    scales = scales(find(scales ~= 1));
    while count <= size(samples,2) - 1 + N_scale
        [temp I] = getScaleSample(im,bb',scales(count - size(samples,2) + 1),opt.tmplsize);
        X(:,count) = temp(:);
        if DEBUG
                imgs{count} = I;
        end
        count = count + 1;
    end
    
    
    %then handling old nagtive samples
    if N_nag > 0
        while count<=size(samples,2) + N_nag - 1 + N_scale
                X(:,count) = nag.X(:,count - size(samples,2) + 1 - N_scale); 
                if DEBUG
                    imgs{count} = nag.imgs{count - size(samples,2) + 1 - N_scale};
                end
                count = count + 1;
        end
    end
    %handing new postive samples
   
    I = XX{end};
    temp = genHoGFeature(I);
    o = temp(:);
    X(:,count) = o; 
    
    if DEBUG
        imgs{count} = I;
    end
    
    if ~first.built
        first.X = X(:,count);
    end
    
    count = count + 1;
    %handling old postive samples
    if N_pos > 0
        while count<=size(samples,2) + N_nag  + N_pos + N_scale
                X(:,count) = pos.X(:,count - size(samples,2) - N_nag - N_scale);
                if DEBUG
                    imgs{count} = pos.imgs{count - size(samples,2) - N_nag - N_scale};
                end
                count=count+1;
        end
    end
    
   
    
    if first.built
        X(:,count) = first.X;
    end
    
    Y = zeros(1,N + N_nag + N_pos);
    count = 1;
	while count<= N - 1
        s = Eval(model,X(:,count));
        if N_pos == 0
            s = Overlap(bb',samples(:,count));
        end
       
		Y(count) = s * (1 - opt.UPDATE_RATE) +  opt.UPDATE_RATE * Overlap(bb',samples(:,count));
        %Y(count) = 1- Overlap(bb',samples(:,count));
        count = count + 1;
    end
    
    while count <= size(samples,2) - 1 + N_scale
        s = Eval(model,X(:,count));
        if N_pos == 0
            s = (1 - abs(1- scales(count - size(samples,2) + 1)));
        end
        Y(count) =  s * (1 - opt.UPDATE_RATE) +  opt.UPDATE_RATE *(1 - abs(1- scales(count - size(samples,2) + 1)));
       
        count = count + 1;
    end
    
    if N_nag > 0
        while count <=N + N_nag - 1 + N_scale
            Y(count) = nag.Y(count - N + 1 - N_scale);
            count = count + 1;
        end
    end
 
    max_score = Eval(model,X(:,count));
    if N_pos == 0
        max_score = 1;
    end
    
     Y(count) = (1 -opt.UPDATE_RATE)* max_score+  opt.UPDATE_RATE*Overlap(bb',samples(:,end));
    if ~first.built
        first.Y = Y(count);
        first.built = false;
    end
    
    count = count + 1;
    if N_pos > 0
     while count<=N + N_nag + N_pos + N_scale
		Y(count) = pos.Y(count - N - N_nag - N_scale);
        count = count + 1;
     end
    end
	
    if first.built
        Y(count) = first.Y;
    end
    
    
   
    K = zeros(N+N_pos + N_nag + N_scale,N + N_pos + N_nag + N_scale);
    
    
   
    %now,calculate the kernel matrix K
    
    for i = 1:size(K,2)
    	 j = 1;
         a = X(:,i);
        while j <=N+ N_nag - 1 + N_scale
            b = X(:,j);
            K(i,j) = -kernel(a,b);
            j = j + 1;
        end
        b = X(:,j);
      %  if max_score < opt.TRESHOLD 
       %      K(i,j) = -X(:,i)' * X(:,j) /(norm( X(:,i)) * norm( X(:,j)));
      %  else
             K(i,j) = kernel(a,b);
      %  end
        j = j+ 1;
        while j <=N+ N_nag + N_pos + N_scale
            b = X(:,j);
            K(i,j) =  kernel(a,b);
            j = j + 1;
        end
       
    end
    %apg_opts.GEN_PLOTS = true;
   W = lsqnonneg(K, Y');
   if DEBUG
        %figure(3);
       % imshow(K,[]);
       % figure(11);plot(W);
   end
    ii = (find(W > 0.05));
    ii_nag = ii < N_nag + N + N_scale;
    ii_pos = ii > N_nag + N - 1 + N_scale;
    ii_nag = ii(ii_nag);
    ii_pos = ii(ii_pos);
    %if max_score < opt.TRESHOLD 
     %   ii_nag = [ii_nag;ii_pos(1)];
    %    ii_pos = ii_pos(2:end);   
   % end
    model.nag.W = W(ii_nag);
    model.nag.X = X(:,ii_nag);
    model.nag.Y = Y(ii_nag);
    
    if DEBUG
        
        model.nag.imgs = imgs(ii_nag);
    end
    
    model.pos.W = W(ii_pos);
    model.pos.X = X(:,ii_pos);
    model.pos.Y = Y(ii_pos);
    
     if DEBUG
        model.pos.imgs = imgs(ii_pos);
    end
    
    %first.built = true;
    model.first = first;
%     if DEBUG
%          disp(['Positive/Negative support samples:' num2str(size(ii_pos,1)) '/' num2str(size(ii_nag,1))]);
%          figure(12);
%          for i = 1:(size(ii))
%             if(i>100) break;end
%      
%             subplot(10,10,i);
%             imshow(uint8(imgs{ii(i)}),[]);
%             if (ii(i) <  N_nag + N + N_scale)
%                 xlabel(num2str(-W(ii(i))));
%             
%             else
%                 xlabel(num2str(W(ii(i))));
%             end
%          end
%     end
    %err = norm(Y' - K * W)
end