function val = kernel(a,b)
    if lseq(a,zeros(size(a))) || lseq(b,zeros(size(b)))
        val  = 0.0;
        return;
    end
    %val = exp( - 0.7 * norm(a - b));
    
    val = a'*b / (norm(a) * norm(b));
end