function [ X ] = getContext( opt,im )
%GETCONTEXT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    est = opt.est;
     p = est';

     p_bb = est2bb(opt.tmplsize,p);

     p_bb = [p_bb([1 2]),p_bb([3 4])*opt.contxt_padding];

     p = bb2est(p_bb',opt.tmplsize);

     I = warpimg(double(im),affparam2mat(p'), opt.tmplsize);
     %figure(13);
     %imshow(I,[]);
     X = genHoGFeature(I);
     X = X(:);
end

