function score = Eval(model,x)
    score = 0;
     nag = model.nag;
     pos = model.pos;
     
     N_nag = length(nag.W);
     N_pos = length(pos.W);
     if N_nag > 0
             for j = 1:N_nag
                score = score - nag.W(j)*(x'*nag.X(:,j) / (norm(x) * norm(nag.X(:,j))));
             end
     end
     for j = 1:N_pos
            score = score + pos.W(j)*(x'*pos.X(:,j) / (norm(x) * norm(pos.X(:,j))));
     end
end