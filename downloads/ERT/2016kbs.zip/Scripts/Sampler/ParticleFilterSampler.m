%% ParticleFilterSampler: function description
function [wimgs,particles] = ParticleFilterSampler(im,est,sz,N,sigma)
	particles = repmat(affparam2geom(est(:)), [1,N]);
    particles = particles + randn(6,N).*repmat(sigma(:), [1,N]);
    wimgs = warpimg(double(im), affparam2mat(particles), sz);
end
