global opt;

opt.radius = 30; 

opt.UPDATE_FACTOR = 6;
opt.tmplsize = [32 32];
opt.contxtsize = [32 32];
opt.contxt_padding = 1;
opt.UPDATE_RATE = 0.3;
opt.scale_range = 0.2;
opt.N_scale = 16;
opt.scale_search_range = 0.4;
opt.N_search_scale = 100;
opt.high_bound = 0.8;
opt.low_bound = 0.3;
%%definition:


DEBUG = 0;

opt.DEBUG = DEBUG;

VISUAL_CHACKING = 1;

VISUAL_FIG = [];

opt.particles.N = 500;


opt.particles.sigma = [12,  12, 0.02, 0.0, 0.0, 0.0]';

